#!/usr/bin/env python3
"""Record exactly one baseline attempt, including incomplete/failed outcomes."""
import argparse,hashlib,json,os,signal,subprocess,sys,tarfile,time,uuid,shutil,platform
from pathlib import Path
from experiment_processes import terminate_partition

def main():
    p=argparse.ArgumentParser();p.add_argument("--seed",type=int,default=900);p.add_argument("--faults",choices=["none","recovery"],default="recovery");p.add_argument('--source-root',required=True);p.add_argument('--manifest',required=True);p.add_argument('--archive',required=True);p.add_argument('--output-dir',required=True);p.add_argument('--simulation-limit',type=float,default=2400.);p.add_argument('--wall-limit',type=float,default=14400.);p.add_argument('--speed',type=float,default=24.)
    args=p.parse_args();out=Path(args.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    root=Path(args.source_root).resolve()
    metadata=json.loads(Path(args.manifest).read_text());manifest=metadata['files']
    mismatches=[n for n,h in manifest.items() if hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
    if mismatches:raise RuntimeError('Frozen source mismatch: '+str(mismatches))
    shutil.copy2(args.manifest,out/'source-manifest.json');shutil.copy2(args.archive,out/'recorded-source.tar.gz')
    shutil.copy2(__file__,out/'record-run.py')
    (out/'environment.json').write_text(json.dumps(dict(platform=platform.platform(),python=platform.python_version(),cpu_count=os.cpu_count(),ros_distro=os.environ.get('ROS_DISTRO'),colima_profile='annual-fusion',cpu_assignment=6,memory_assignment_gib=8,frozen_source_root=str(root)),indent=2))
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',LP_NUM_THREADS='2',DISPLAY=':97',LIBGL_ALWAYS_SOFTWARE='1',QT_X11_NO_MITSHM='1',PYTHONDONTWRITEBYTECODE='1',
        ANNUAL_EXPERIMENT_SEED=str(args.seed),GZ_PARTITION='annual_todo_video_'+uuid.uuid4().hex,ROS_DOMAIN_ID=str(20+int(uuid.uuid4().hex[:4],16)%180))
    env['PYTHONPYCACHEPREFIX']='/tmp/'+env['GZ_PARTITION']+'_pycache'
    (out/'transport.json').write_text(json.dumps({k:env[k] for k in ('GZ_PARTITION','ROS_DOMAIN_ID')},indent=2))
    (out/'run-configuration.json').write_text(json.dumps(dict(base_commit=metadata['base_commit'],includes_uncommitted_changes=metadata['includes_uncommitted_changes'],arguments=vars(args),comparison='Development candidate: team-new utility, service lifecycle, deadline worker and authorized moving handoff; same native 3D sensor and map.'),indent=2))
    servers=[];observer=None
    if not Path('/tmp/.X11-unix/X97').exists():
        servers.append(subprocess.Popen(['Xvfb',':97','-screen','0','1920x1080x24','-ac'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
        for _ in range(100):
            if Path('/tmp/.X11-unix/X97').exists():break
            time.sleep(.1)
        servers.append(subprocess.Popen(['openbox'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    log=(out/'launch.log').open('w');proc=None;recorder=None;result={};last=None
    start=time.monotonic()
    try:
        recorder=subprocess.Popen(['ffmpeg','-y','-loglevel','warning','-f','x11grab','-framerate','10','-video_size','1920x1080','-i',env['DISPLAY'],'-c:v','libx264','-preset','ultrafast','-crf','23','-threads','1','-pix_fmt','yuv420p',str(out/'gazebo-rviz-raw.mp4')],env=env,stdout=log,stderr=log)
        observer=subprocess.Popen([sys.executable,str(root/'ros2_ws/src/annual_swarm/scripts/record_observation_evidence.py'),'--ros-args','-p','use_sim_time:=true','-p',f'output_dir:={out}'],env=env,stdout=log,stderr=log,start_new_session=True)
        command=['ros2','launch','annual_swarm','decentralized_search.launch.py','headless:=false','rviz:=true','visualize:=true',f'output_dir:={out}',f'map:={root}/next_project/maps/search_fusion_3d.json']
        if args.faults=='none':command+=['pause_after:=0','network_after:=0','restart_after:=0','dynamic_obstacle:=false']
        proc=subprocess.Popen(command,env=env,stdout=log,stderr=log,start_new_session=True)
        arranged=set();holding=None;bad_since={}
        while time.monotonic()-start<args.wall_limit:
            if proc.poll() is not None:raise RuntimeError('Launch exited')
            if len(arranged)<2:
                for name,selector,geo in [('gazebo',['--name','^Gazebo Sim$'],[0,40,800,1000]),('rviz',['--class','rviz'],[800,40,1120,1000])]:
                    if name in arranged:continue
                    found=subprocess.run(['xdotool','search','--onlyvisible',*selector],env=env,capture_output=True,text=True)
                    if found.returncode==0 and found.stdout.strip():
                        wid=found.stdout.splitlines()[-1];subprocess.run(['xdotool','windowmove',wid,*map(str,geo[:2]),'windowsize',wid,*map(str,geo[2:])],env=env,check=True);arranged.add(name)
                if time.monotonic()-start>120 and len(arranged)!=2:raise RuntimeError('Native GUI windows missing')
            file=out/'summary.json'
            if file.exists():
                try:s=json.loads(file.read_text())
                except (json.JSONDecodeError,FileNotFoundError):time.sleep(.2);continue
                last=s
                if time.time()-file.stat().st_mtime>90:raise RuntimeError('Telemetry stopped')
                if s['status']=='FAILED':result=dict(outcome='FAILED',reason=s.get('failure_reason'));break
                # A zero contact counter alone cannot certify flight: also stop
                # on sustained loss of airborne tracking, retaining raw evidence.
                peer_file=out/'peer_states.jsonl'
                if s.get('start_time') is not None and s['simulation_time']>s['start_time']+5 and peer_file.exists():
                    with peer_file.open('rb') as stream:
                        size=stream.seek(0,2);stream.seek(max(0,size-262144));lines=stream.read().splitlines()
                    latest={}
                    for line in lines:
                        try:state=json.loads(line)
                        except (json.JSONDecodeError,UnicodeDecodeError):continue
                        latest[state['drone']]=state
                    for i,state in latest.items():
                        error=state.get('execution',{}).get('tracking_error',0.)
                        bad=state['position'][2]<.5 or error>.8
                        if bad:
                            bad_since.setdefault(i,state['time'])
                            if state['time']-bad_since[i]>=1.:
                                result=dict(outcome='EXECUTION_FAILURE',reason='Sustained landing or tracking loss',drone=i,time=state['time'],estimated_position=state['position'],tracking_error_m=error)
                        else:bad_since.pop(i,None)
                    if result:break
                if s['status']=='COMPLETE':
                    if holding is None:holding=s['simulation_time']
                    if s['simulation_time']-holding>=3.:result=dict(outcome='COMPLETE');break
                if s.get('start_time') is not None and s['simulation_time']-s['start_time']>=args.simulation_limit:
                    result=dict(outcome='SIMULATION_TIME_LIMIT',reason='Did not reach 95% within the preregistered limit');break
                if s['simulation_time']>50 and len(s.get('agent_ages',{}))!=3:raise RuntimeError('An exploration agent failed to start')
                if max(s.get('agent_ages',{}).values(),default=0)>15.:raise RuntimeError('Exploration heartbeat stopped')
            elif time.monotonic()-start>180:raise RuntimeError('No experiment telemetry')
            time.sleep(1)
        if not result:result=dict(outcome='WALL_TIME_LIMIT')
    except (Exception, KeyboardInterrupt) as exc:
        result=dict(outcome='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'INFRASTRUCTURE_FAILURE',reason=repr(exc))
    finally:
        result.update(wall_elapsed_s=time.monotonic()-start,last_coverage=last.get('coverage') if last else None,last_simulation_time=last.get('simulation_time') if last else None)
        (out/'run-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
        if not (out/'observed_final.npz').exists() and proc and proc.poll() is None:
            try:
                subprocess.run([sys.executable,str(Path(__file__).with_name('snapshot_map.py')),str(out)],env=env,timeout=12,check=True,stdout=log,stderr=log)
            except Exception as exc:
                (out/'map-snapshot-error.txt').write_text(repr(exc))
        if recorder and recorder.poll() is None:
            recorder.send_signal(signal.SIGINT);recorder.wait(timeout=30)
        if proc and proc.poll() is None:
            proc.send_signal(signal.SIGINT)
            try:proc.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
        if observer and observer.poll() is None:
            observer.send_signal(signal.SIGINT)
            try:observer.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(observer.pid,signal.SIGKILL);observer.wait()
        # Limit cleanup to the unique transport partition of this attempt.
        cleanup=terminate_partition(env['GZ_PARTITION'])
        (out/'process-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
        if cleanup['remaining']:raise RuntimeError('Owned experiment processes survived cleanup')
        for server in reversed(servers):server.terminate()
        log.close()
    final=out/'todo-exploration.mp4'
    title=f'FUSED 3D EXPLORATION | TEAM GAIN + AUTHORIZED HANDOFF | {args.speed:g}x recording speed'
    filters=f"setpts=PTS/{args.speed},drawbox=x=0:y=0:w=iw:h=38:color=0x121923:t=fill,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='{title}':x=16:y=9:fontsize=20:fontcolor=white"
    subprocess.run(['ffmpeg','-y','-loglevel','warning','-i',str(out/'gazebo-rviz-raw.mp4'),'-vf',filters,'-r','30','-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',str(final)],check=True)
    probe=subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(final)],text=True)
    (out/'video-probe.json').write_text(probe)
    print(final,flush=True)
if __name__=='__main__':main()
