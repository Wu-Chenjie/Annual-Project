# 冷启动接触冲量：同一传感记录回放对照

`sensors.jsonl` 来自真实 Gazebo 失败运行，按探针收到消息的顺序记录三机 IMU、带噪定位、估计与真值。约 0.07 s 落地冲量改变速度，但采样 IMU 没有包含该瞬时冲量。

`filter-before.py` 来自提交 314fd02；`filter-fixed.py` 增加连续白加速度模型不确定性的正确离散化。执行 `python3 replay.py`（需要 numpy/scipy）会对同一份输入分别运行两个滤波器，写出 `replay-results.json`。

探针与原估计进程的 ROS 调度顺序可能不同。这里比较的是探针记录的同一输入顺序，不能把离线回放输出冒充当时飞行器已使用的估计。位置误差将每条真值与当时最新已处理 IMU 的估计作比较，包含少量时间差；这是启动缺陷回归证据，不是 SLAM 精度基准。独立修复后冷启动另见 packaged-startup.json。
