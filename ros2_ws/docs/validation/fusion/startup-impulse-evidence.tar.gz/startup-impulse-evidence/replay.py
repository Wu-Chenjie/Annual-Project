"""Replay the same recorded sensor arrival order against both filter versions."""
import importlib.util,json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
root=Path(__file__).parent
records=[json.loads(line) for line in (root/'sensors.jsonl').open()]
results={}
for filename in ('filter-before.py','filter-fixed.py'):
    spec=importlib.util.spec_from_file_location('filter_version',root/filename)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    results[filename]=[]
    for i in range(3):
        f=module.InertialOdometryFilter();queue=[];lastok=None;errors=[]
        for r in records:
            if r['drone']!=i:continue
            t=r['stamp']
            if r['kind']=='localization_measurement':
                queue.append(r);queue.sort(key=lambda x:x['stamp'])
            if r['kind']=='imu':
                f.predict(t,Rotation.from_quat(r['q']).apply(r['a'])+[0,0,-9.81])
                while queue and queue[0]['stamp']<=t:
                    m=queue.pop(0)
                    if f.correct_at(m['stamp'],m['p'],Rotation.from_quat(m['q']).apply(m['v']),np.diag([.007**2]*3+[.015**2]*3)):
                        lastok=m['stamp']
            if r['kind']=='odometry' and f.initialized:errors.append(np.linalg.norm(f.x[:3]-r['p']))
        results[filename].append(dict(drone=i,updates=f.updates,rejected=f.rejected,last_accepted_stamp=lastok,position_error_p95_m=float(np.percentile(errors,95)),position_error_max_m=float(max(errors))))
(root/'replay-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
